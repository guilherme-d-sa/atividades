public interface Tributavel {
    //Metodo

    public  Double getValorTributo();
}
