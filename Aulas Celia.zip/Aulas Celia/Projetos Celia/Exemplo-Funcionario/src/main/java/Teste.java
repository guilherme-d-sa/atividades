public class Teste {
    public static void main(String[] args) {


        Engenheiro e= new Engenheiro("12345","mario",2000.0);
        Vendedor v= new Vendedor("32145","joão",22.0,300.0);
        Horista h= new Horista("55658","outro joão",12,70.0);







        System.out.println(e);
        System.out.println(v);
        System.out.println(h);
    }
}
