package br.com.estudos.agua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AguaApplicationTests {

	@Test
	void contextLoads() {
	}

}
