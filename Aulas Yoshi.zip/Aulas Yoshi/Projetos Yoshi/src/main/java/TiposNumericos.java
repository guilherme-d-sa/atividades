public class TiposNumericos {
    public static void main(String[] args) {

        long bacteriasNoMundo = 99999999999L; // primitivo
        Long microbiosNoMundo = 99999999999L; // wrapper


        short expectadoresShow = 15000; //primitivo

        Short expectadoresPalestra = 15000; //wrapper
    }
}
