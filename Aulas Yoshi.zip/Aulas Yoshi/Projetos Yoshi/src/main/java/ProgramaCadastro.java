public class ProgramaCadastro {
    public static void main(String[] args) {
        Cadastro novoCadastro = new Cadastro();

        System.out.println("Filhos: "+novoCadastro.filhos);
        System.out.println("Altura: "+novoCadastro.altura);
        System.out.println("É casado: "+novoCadastro.casado);

        System.out.println("Dentes: "+novoCadastro.dentes);
        System.out.println("Peso: "+novoCadastro.peso);
        System.out.println("É alfabetizado: "+novoCadastro.alfabetizados);
    }
}
