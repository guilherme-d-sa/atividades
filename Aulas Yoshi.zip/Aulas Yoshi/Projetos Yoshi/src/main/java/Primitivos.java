public class Primitivos {

    public static void main(String[] args) {
        Integer filhos = null;

        System.out.println("Filhos: "+filhos);
        System.out.println("Filhos: "+filhos.toString());


        int idadeEMAnos = 0;

        System.out.println("Idade(anos): "+idadeEMAnos);
        System.out.println("Idade(anos): "+idadeEMAnos);


        Boolean ehCasadoWrapper = null;
        boolean ehCasadoPrimitivo = true;

        String letraWrapper = "S";
        char letraPrimitivo = 'S'; //aqui sempre com aspas simples e somente 1

        Float alturaWrapper = 1.90f; // Floar:somos obrigados a por o "F" ao final
    }
}
