import com.sun.org.apache.xpath.internal.operations.Bool;

public class Cadastro {

    public  int filhos;
    public double altura;
    public  boolean casado;

    public  Integer dentes;
    public  Double peso;
    public Boolean alfabetizados;

}
