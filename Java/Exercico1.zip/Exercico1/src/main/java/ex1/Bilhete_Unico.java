/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

/**
 *
 * @author Aluno
 */
public class Bilhete_Unico {
    
    private String cpf;
    private Double saldo;

    public Bilhete_Unico(String cpf, Double saldo, String titular) {
        this.cpf = cpf;
        this.saldo = saldo;
        this.titular = titular;
    }
    private String titular;
    
   

    
    
     public void recarregar (){
        if(this.saldo>250.00){
            System.out.println("Valor não permitido");
        }
    }
    public void passagemComum (){
        if(this.saldo>0.00){
           this.saldo -=4.50;
        }
        if(this.saldo==0.00){
            this.saldo = 0.00;
        }
         System.out.println("Saldo:"+saldo);
    }
    
    public void passagemIntegracao (){
        if(this.saldo>0){
            this.saldo -=1.50;
        }
        System.out.println("Saldo:"+saldo);
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

   
}
