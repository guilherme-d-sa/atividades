/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

/**
 *
 * @author Aluno
 */
public class TesteBilhete {
     public static void main(String[] args) {
        Bilhete_Unico bilhete1 = new Bilhete_Unico("123456", 200.00, "joao silva");
        
        bilhete1.recarregar();
         System.err.println("");
        bilhete1.passagemComum();
         System.err.println("");
        bilhete1.passagemIntegracao();
         System.err.println("");
         
          bilhete1.recarregar();
         System.err.println("");
        bilhete1.passagemComum();
         System.err.println("");
        bilhete1.passagemIntegracao();
         System.err.println("");
    }
     
}
